from django.db import models
from django.utils import timezone

# Create your models here.

class KriptFichModel(models.Model):
	FichKripte = models. FileField(upload_to='Kript')
	
	def save(self, *args, **kwargs):
		super(KriptFichModel, self).save(*args, **kwargs)