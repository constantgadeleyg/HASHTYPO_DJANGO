from django.urls import path
from . import views

urlpatterns = [
    path('', views.Akey),
    path('Enskri/', views.Enskri), 
    path('Konekte/', views.Konekte), 
    path('Kripte/', views.Kripte),
]