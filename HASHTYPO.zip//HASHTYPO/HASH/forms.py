from django import forms
from django.core.exceptions import ValidationError

class FomKripte(forms.Form):
	FichKripte = forms.FileField(required = True)
	
	def clean(self):
		cleaned_data=super().clean()
		FichKripte = self.cleaned_data['FichKripte']