from django.http import HttpResponse
from django.shortcuts import render, redirect
from .forms import *
from django.contrib.auth import authenticate, login, logout
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
import pyminizip


# Create your views here.

def Akey(request):
	return render(request, 'Akey.html')
	
	
def Enskri(request):
    if request.method=='POST':
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        confpassword=request.POST.get('confpassword')
        if password!=confpassword:
            pass
            #add_error("Ote", "Antre nonw ak siyatiw Konple")
            #raise ValidationError("Konfimasyon non korek")
        else:
            User.objects.create_user(username=username,email=email,password=password)
            return redirect(Akey)
        #print(email)


    context={

    }
    return render(request, 'Enskri.html', context)

	
			
def Konekte(request):
    if request.method == "POST":
        non = request.POST['non']
        password = request.POST['password']
        user = authenticate(username=non, password=password)
        if user is not None:
            login(request, user)
            print("Itilizatè a otantifye, li konekte")
            return redirect(Akey)
        else:
            print("Idantifyan yo pa bon")
    context = {
        'user':User.objects.filter(is_active=True)
    }
    return render(request, "Konekte.html", context)	
	
	

	
def Kripte(request):
	# input file path
	inpt = "./Text.txt"
	
	# prefix path
	pre = None
	
	# output zip file path
	oupt = "./output.zip"
	
	# set password value
	password = "GFG"
	
	# compress level
	com_lvl = 5
	
	# compressing file
	pyminizip.compress(inpt, None, oupt,
                   password, com_lvl)
	
	
	return render(request, 'Kripte.html')
	


def Dekonekte(request):
    logout(request)
    return redirect(Akey)